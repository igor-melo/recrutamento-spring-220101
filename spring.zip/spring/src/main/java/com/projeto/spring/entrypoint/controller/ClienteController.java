package com.projeto.spring.entrypoint.controller;


import com.projeto.spring.datarpovider.entities.ClienteEntity;
import com.projeto.spring.entrypoint.mapper.ClienteEntryPointDomainMapper;
import com.projeto.spring.entrypoint.mapper.ClienteEntryPointModelMapper;
import com.projeto.spring.entrypoint.model.request.ClienteModelRequest;
import com.projeto.spring.entrypoint.model.response.ClienteModelResponse;
import com.projeto.spring.usecase.domain.request.ClienteDomainRequest;
import com.projeto.spring.usecase.domain.response.ClienteDomainResponse;
import com.projeto.spring.usecase.service.ClienteUseCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/cliente")
public class ClienteController {

    @Autowired
    private ClienteUseCase clienteUseCase;

    @GetMapping(value = "listarpor/nome/{nome}")
    public ResponseEntity<List<ClienteModelResponse>> listarClientePorNome(@PathVariable String nome) {
        ClienteDomainRequest clienteDomainRequest = ClienteEntryPointDomainMapper.fromDomain(null, nome);
        Optional<List<ClienteDomainResponse>> objResponse = clienteUseCase.listarClientePorNome(clienteDomainRequest);
        return ResponseEntity.ok().body(ClienteEntryPointModelMapper.toClienteModelResponse(objResponse.get()));
    }

    @GetMapping(value = "listarpor/id/{id}")
    public ResponseEntity<List<ClienteModelResponse>> listarClientePorNome(@PathVariable Long id) {
        ClienteDomainRequest clienteDomainRequest = ClienteEntryPointDomainMapper.fromDomain(id, null);
        List<ClienteDomainResponse> objResponse = Arrays.asList(clienteUseCase.listarClientePorId(clienteDomainRequest));
        return ResponseEntity.ok().body(ClienteEntryPointModelMapper.toClienteModelResponse(objResponse));

    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        ClienteDomainRequest clienteDomainRequest = ClienteEntryPointDomainMapper.fromDomain(id, null);
        clienteUseCase.deleteCliente(clienteDomainRequest);
        return  ResponseEntity.noContent().build();
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<Void> update(@RequestBody ClienteModelRequest cliente, @PathVariable Long id) {
        ClienteDomainRequest clienteDomainRequest = ClienteEntryPointDomainMapper.fromDomain(id, null);
        ClienteDomainResponse objResponse = clienteUseCase.listarClientePorId(clienteDomainRequest);
        objResponse.setNomeCompleto(cliente.getNomeCompleto());


        clienteUseCase.salvarCliente(objResponse, id);

        ClienteEntity cli = new ClienteEntity(objResponse.getId(), objResponse.getNomeCompleto(), objResponse.getSexo(), objResponse.getNascimento(), objResponse.getIdade(), objResponse.getCidade());
        //clienteUseCase.salvarCliente(clienteDomainRequest, id);
//        obj.setId(id);
//        obj = service.update(obj);

        return ResponseEntity.noContent().build();
    }

}
