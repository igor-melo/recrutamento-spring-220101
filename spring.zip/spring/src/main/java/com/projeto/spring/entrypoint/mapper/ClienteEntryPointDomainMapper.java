package com.projeto.spring.entrypoint.mapper;

import com.projeto.spring.usecase.domain.request.ClienteDomainRequest;

public class ClienteEntryPointDomainMapper {

    private ClienteEntryPointDomainMapper() {
    }

    public static ClienteDomainRequest fromDomain(Long id, String nome){
        return new ClienteDomainRequest(id, nome);
    }


}
