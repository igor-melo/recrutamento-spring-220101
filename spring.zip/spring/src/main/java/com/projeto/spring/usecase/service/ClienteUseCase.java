package com.projeto.spring.usecase.service;

import com.projeto.spring.usecase.domain.request.ClienteDomainRequest;
import com.projeto.spring.usecase.domain.response.ClienteDomainResponse;
import com.projeto.spring.usecase.gateway.ClienteGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@Component
public class ClienteUseCase {


    private ClienteGateway clienteGateway;

    @Autowired
    public ClienteUseCase(ClienteGateway clienteGateway) {
        this.clienteGateway = clienteGateway;
    }

    public Optional<List<ClienteDomainResponse>> listarClientePorNome(ClienteDomainRequest clienteDomainRequest){
        return clienteGateway.listarClientePorNome(clienteDomainRequest.getNomeCompleto());
    }

    public ClienteDomainResponse listarClientePorId(ClienteDomainRequest clienteDomainRequest){
        return clienteGateway.listarClientePorId(clienteDomainRequest.getId());
    }
    public void deleteCliente(ClienteDomainRequest clienteDomainRequest){
        clienteGateway.deletarCliente(clienteDomainRequest.getId());
    }

    public void salvarCliente(ClienteDomainRequest cliente, @PathVariable Long id){
        clienteGateway.salvarCliente(cliente, id);
    }

}
