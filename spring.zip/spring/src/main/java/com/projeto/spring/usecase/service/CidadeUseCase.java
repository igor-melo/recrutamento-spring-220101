package com.projeto.spring.usecase.service;

import com.projeto.spring.usecase.domain.request.CidadeDomainRequest;
import com.projeto.spring.usecase.domain.response.CidadeDomainResponse;
import com.projeto.spring.usecase.gateway.CidadeGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class CidadeUseCase {


    private CidadeGateway cidadeGateway;

    @Autowired
    public CidadeUseCase(CidadeGateway cidadeGateway) {
        this.cidadeGateway = cidadeGateway;
    }

    public Optional<List<CidadeDomainResponse>> listarCidadePorNome(CidadeDomainRequest cidadeDomainRequest){
        return cidadeGateway.listarCidadePorNome(cidadeDomainRequest.getNome());
    }

    public Optional<List<CidadeDomainResponse>> atualizarCliente(CidadeDomainRequest cidadeDomainRequest, Long Id){
        return cidadeGateway.listarCidadePorNome(cidadeDomainRequest.getNome());
    }
}
