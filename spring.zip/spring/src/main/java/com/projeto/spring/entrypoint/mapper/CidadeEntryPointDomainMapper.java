package com.projeto.spring.entrypoint.mapper;

import com.projeto.spring.usecase.domain.request.CidadeDomainRequest;

public class CidadeEntryPointDomainMapper {

    private CidadeEntryPointDomainMapper() {
    }

    public static CidadeDomainRequest fromDomain(String nome, String estado){
        return new CidadeDomainRequest(nome, estado);
    }


}
